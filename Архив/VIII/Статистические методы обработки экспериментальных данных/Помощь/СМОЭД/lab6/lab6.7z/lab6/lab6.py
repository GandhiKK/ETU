import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.colors as colors
import random
np.random.seed(999)
random.seed(999)
df = pd.read_csv('sample.csv')
df.columns = ['x', 'y']

N = np.sqrt(len(df) / 2).astype(np.int64)
dict_colors = {i: name for i, (name, col) in enumerate(random.choices(list(colors.CSS4_COLORS.items()), k=N))}
list_colors = [name for name, col in random.choices(list(colors.CSS4_COLORS.items()), k=N)]

centroids = df.sample(N)


def dists_to_centroids(point, cur_centroids):
    return cur_centroids.apply(lambda x: np.linalg.norm(x - point), axis=1)


def get_closest_centroids(points, cur_centroids):
    return points.apply(lambda x: np.argmin(dists_to_centroids(x, cur_centroids)), axis=1)


def move_centroids(points, closest_centroids, num_of_centroids):
    return np.array([points[closest_centroids == c].mean(axis=0) for c in range(num_of_centroids)])


while True:
    prev_centroids = centroids.copy()
    cl_centroids = get_closest_centroids(df, centroids)
    centroids[:] = move_centroids(df, cl_centroids, N)

    ax = df.plot.scatter(x=0, y=1, c=cl_centroids.apply(lambda x: dict_colors[x]))
    ax.scatter(centroids.x, centroids.y, c='red')
    plt.show()

    if ((prev_centroids - centroids).mean(axis=0).abs() < [0.0001, 0.0001]).all():
        break

